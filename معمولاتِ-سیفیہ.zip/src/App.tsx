/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Clock, 
  MapPin, 
  ChevronDown, 
  ChevronUp, 
  BookOpen, 
  Info, 
  Search,
  Edit2,
  Moon,
  Sun,
  Sunrise,
  Sunset,
  Zap,
  Play,
  Pause,
  Volume2,
  Loader2
} from 'lucide-react';
import { formatInTimeZone } from 'date-fns-tz';
import { cn } from './lib/utils';

// --- Types ---
interface PrayerTimes {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Sunset: string;
  Maghrib: string;
  Isha: string;
  Imsak: string;
  Midnight: string;
  Firstthird: string;
  Lastthird: string;
}

interface LocationData {
  city: string;
  lat: number;
  lon: number;
  timezone: string;
}

interface ShajraItem {
  name: string;
  bio: string;
}

interface MuraqabaItem {
  title: string;
  text: string;
}

// --- Constants & Data ---
const KHATMS = [
  { name: "ختم حضرت ابوبکر صدیق رضی اللہ عنہ", zikr: "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ سُبْحَانَ اللّٰهِ الْعَظِيْمِ" },
  { name: "ختم خلفائے ثلاثہ (عمر، عثمان، علی رضی اللہ عنہ)", zikr: "سُبْحَانَ اللّٰهِ وَالْحَمْدُ لِلّٰهِ وَلَا اِلٰهَ اِلَّا اللّٰهُ وَاللّٰهُ اَكْبَرُ" },
  { name: "ختم امام ربانی مجدد الف ثانی رحمۃ اللہ علیہ", zikr: "وَلَا حَوْلَ وَلَا قُوَّةَ اِلَّا بِاللّٰهِ" },
  { name: "ختم شیخ عبدالقادر جیلانی رحمۃ اللہ علیہ", zikr: "حَسْبُنَا اللّٰهُ وَنِعْمَ الْوَكِيْلُ" },
  { name: "ختم خواجہ معصوم اول رحمۃ اللہ علیہ", zikr: "لَا اِلٰهَ اِلَّا اَنْتَ سُبْحٰنَكَ اِنِّيْ کُنْتُ مِنَ الظّٰلِمِيْنَ" },
  { name: "ختم حضرت شاہ نقشبند رحمۃ اللہ علیہ", zikr: "يَا خَفِيَّ اللُّطْفِ اَدْرِكْنَا بِلُطْفِكَ الْخَفِيِّ" }
];

const SHAJRA_NAQSHBANDI: ShajraItem[] = [
  { name: "سیدنا محمد رسول اللہ ﷺ", bio: "خاتم النبیین۔ مزار: مدینہ منورہ، سعودی عرب۔" },
  { name: "حضرت ابوبکر صدیق رضی اللہ عنہ", bio: "پہلے خلیفہ راشد، یارِ غار۔ مزار: روضہ رسول ﷺ، مدینہ منورہ۔" },
  { name: "حضرت سلمان فارسی رضی اللہ عنہ", bio: "مشہور صحابی رسول ﷺ۔ مزار: مدائن، عراق۔" },
  { name: "حضرت قاسم بن محمد بن ابی بکر رحمۃ اللہ علیہ", bio: "جلیل القدر تابعی۔ مزار: جنت البقیع، مدینہ منورہ۔" },
  { name: "حضرت امام جعفر صادق رحمۃ اللہ علیہ", bio: "عظیم پیشوائے طریقت۔ مزار: جنت البقیع، مدینہ منورہ۔" },
  { name: "حضرت بایزید بسطامی رحمۃ اللہ علیہ", bio: "سلطان العارفین۔ مزار: بسطام، ایران۔" },
  { name: "حضرت ابوالحسن خرقانی رحمۃ اللہ علیہ", bio: "عظیم صوفی بزرگ۔ مزار: خرقان، ایران۔" },
  { name: "حضرت ابو علی فارمدی رحمۃ اللہ علیہ", bio: "مزار: طوس (موجودہ مشہد کے قریب)، ایران۔" },
  { name: "حضرت خواجہ یوسف ہمدانی رحمۃ اللہ علیہ", bio: "مزار: مرو، ترکمانستان۔" },
  { name: "حضرت خواجہ عبدالخالق غجدوانی رحمۃ اللہ علیہ", bio: "طریقہ خواجگان کے بانی۔ مزار: غجدوان، ازبکستان۔" },
  { name: "حضرت خواجہ عارف ریوگری رحمۃ اللہ علیہ", bio: "مزار: ریوگر، بخارا، ازبکستان۔" },
  { name: "حضرت خواجہ محمود انجیر فغنوی رحمۃ اللہ علیہ", bio: "مزار: فغنہ، بخارا، ازبکستان۔" },
  { name: "حضرت خواجہ علی رامتینی رحمۃ اللہ علیہ", bio: "مزار: خوارزم، ازبکستان۔" },
  { name: "حضرت خواجہ محمد بابا سماسی رحمۃ اللہ علیہ", bio: "مزار: سماس، بخارا، ازبکستان۔" },
  { name: "حضرت خواجہ سید امیر کلال رحمۃ اللہ علیہ", bio: "مزار: سوخار، بخارا، ازبکستان۔" },
  { name: "حضرت خواجہ بہاؤالدین نقشبند رحمۃ اللہ علیہ", bio: "سلسلہ عالیہ نقشبندیہ کے بانی۔ مزار: قصرِ عارفاں، بخارا۔" },
  { name: "حضرت خواجہ علاؤ الدین عطار رحمۃ اللہ علیہ", bio: "مزار: چغانیاں، تاجکستان۔" },
  { name: "حضرت خواجہ یعقوب چرخی رحمۃ اللہ علیہ", bio: "مزار: dushonbe کے قریب حصار، تاجکستان۔" },
  { name: "حضرت خواجہ عبیداللہ احرار رحمۃ اللہ علیہ", bio: "سمرقند، ازبکستان۔" },
  { name: "حضرت خواجہ محمد زاہد وخشى رحمۃ اللہ علیہ", bio: "وخش، تاجکستان۔" },
  { name: "حضرت خواجہ درویش محمد رحمۃ اللہ علیہ", bio: "اسفرار، ازبکستان۔" },
  { name: "حضرت خواجہ محمد امکنگی رحمۃ اللہ علیہ", bio: "امکنگ، ازبکستان۔" },
  { name: "حضرت خواجہ محمد باقی باللہ رحمۃ اللہ علیہ", bio: "دہلی، بھارت۔" },
  { name: "حضرت امام ربانی مجدد الف ثانی رحمۃ اللہ علیہ", bio: "سرہند شریف، بھارت۔" },
  { name: "حضرت خواجہ محمد معصوم رحمۃ اللہ علیہ", bio: "سرہند شریف، بھارت۔" },
  { name: "حضرت خواجہ صبغۃ اللہ رحمۃ اللہ علیہ", bio: "سرہند شریف، بھارت۔" },
  { name: "حضرت خواجہ محمد اسماعیل رحمۃ اللہ علیہ", bio: "سرہند شریف، بھارت۔" },
  { name: "حضرت حاجی غلام محمد معصوم ثانی رحمۃ اللہ علیہ", bio: "پشاور، پاکستان۔" },
  { name: "حضرت شاہ غلام محمد رحمۃ اللہ علیہ", bio: "پشاور، پاکستان۔" },
  { name: "حضرت حاجی محمد صفی رحمۃ اللہ علیہ", bio: "پشاور، پاکستان۔" },
  { name: "حضرت شاہ ضیاء الحق رحمۃ اللہ علیہ", bio: "پشاور، پاکستان۔" },
  { name: "حضرت حاجی شاہ ضیاء الرحمٰن رحمۃ اللہ علیہ", bio: "افغانستان۔" },
  { name: "حضرت شمس الحق رحمۃ اللہ علیہ", bio: "افغانستان۔" },
  { name: "حضرت مولانا شاہ رسول طالقانی رحمۃ اللہ علیہ", bio: "طالقان، افغانستان۔" },
  { name: "حضرت مولانا محمد ہاشم سمنگانی رحمۃ اللہ علیہ", bio: "پیر سباق، صوابی (پاکستان)۔" },
  { name: "حضرت اخوندزادہ پیر سیف الرحمٰن مبارک رحمۃ اللہ علیہ", bio: "بانی سلسلہ سیفیہ۔ مزار: جامع مسجد و دربار فقیر آباد شریف، لاہور۔" }
];

const SHAJRA_QADRIA: ShajraItem[] = [
  { name: "سیدنا محمد رسول اللہ ﷺ", bio: "مدینہ منورہ، سعودی عرب۔" },
  { name: "حضرت علی المرتضیٰ رضی اللہ عنہ", bio: "نجف اشرف، عراق۔" },
  { name: "حضرت حسن بصری رحمۃ اللہ علیہ", bio: "بصرہ، عراق۔" },
  { name: "حضرت حبیب عجمی رحمۃ اللہ علیہ", bio: "بصرہ، عراق۔" },
  { name: "حضرت داؤد طائی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت معروف کرخی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت سری سقطی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت جنید بغدادی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت ابوبکر شبلی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت عبدالعزیز بن حارث تمیمی رحمۃ اللہ علیہ", bio: "یمن۔" },
  { name: "حضرت ابوالفضل عبدالواحد تمیمی رحمۃ اللہ علیہ", bio: "بغداد۔" },
  { name: "حضرت ابوالفرح طرطوسی رحمۃ اللہ علیہ", bio: "طرطوس، شام۔" },
  { name: "حضرت ابوالحسن ہنکاری رحمۃ اللہ علیہ", bio: "ہنکار، عراق۔" },
  { name: "حضرت ابو سعید مبارک مخزومی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "سیدنا غوث الاعظم عبدالقادر جیلانی رحمۃ اللہ علیہ", bio: "بانی سلسلہ قادریہ۔ مزار: بغداد شریف، عراق۔" },
  { name: "اس کے بعد کے مشائخ سے ہوتے ہوئے...", bio: "حضرت شاہ عالم دہلوی، شیخ جنید پشاوری، مولانا محمد ہاشم سمنگانی سے فیضان جاری ہوا۔" },
  { name: "حضرت اخوندزادہ پیر سیف الرحمٰن مبارک رحمۃ اللہ علیہ", bio: "مزار: فقیر آباد شریف، لاہور، پاکستان۔" }
];

const SHAJRA_CHISHTIA: ShajraItem[] = [
  { name: "سیدنا محمد رسول اللہ ﷺ", bio: "مدینہ منورہ۔" },
  { name: "حضرت علی المرتضیٰ رضی اللہ عنہ", bio: "نجف اشرف، عراق۔" },
  { name: "حضرت حسن بصری رحمۃ اللہ علیہ", bio: "بصرہ، عراق۔" },
  { name: "خواجہ عبدالواحد بن زید رحمۃ اللہ علیہ", bio: "بصرہ، عراق۔" },
  { name: "خواجہ فضیل بن عیاض رحمۃ اللہ علیہ", bio: "مکہ مکرمہ۔" },
  { name: "خواجہ ابراہیم بن ادہم رحمۃ اللہ علیہ", bio: "شام۔" },
  { name: "خواجہ حذیفہ مرعشی رحمۃ اللہ علیہ", bio: "بصرہ۔" },
  { name: "خواجہ امین الدین ہبیرہ رحمۃ اللہ علیہ", bio: "بصرہ۔" },
  { name: "خواجہ ممشاد علوی دینوری رحمۃ اللہ علیہ", bio: "بغداد۔" },
  { name: "خواجہ ابو اسحاق شامی رحمۃ اللہ علیہ", bio: "دمشق، شام۔" },
  { name: "خواجہ ابو احمد ابدال چشتی رحمۃ اللہ علیہ", bio: "چشت، افغانستان۔" },
  { name: "خواجہ ابو محمد چشتی رحمۃ اللہ علیہ", bio: "چشت، افغانستان۔" },
  { name: "خواجہ ابو یوسف چشتی رحمۃ اللہ علیہ", bio: "چشت، افغانستان۔" },
  { name: "خواجہ قطب الدین مودود چشتی رحمۃ اللہ علیہ", bio: "چشت، افغانستان۔" },
  { name: "خواجہ حاجی شریف زندانی رحمۃ اللہ علیہ", bio: "قنوج، بھارت۔" },
  { name: "خواجہ عثمان ہارونی رحمۃ اللہ علیہ", bio: "مکہ مکرمہ۔" },
  { name: "خواجہ معین الدین چشتی اجمیری رحمۃ اللہ علیہ", bio: "اجمیر شریف، بھارت۔" },
  { name: "خواجہ قطب الدین بختیار کاکی رحمۃ اللہ علیہ", bio: "دہلی، بھارت۔" },
  { name: "خواجہ فرید الدین مسعود گنج شکر رحمۃ اللہ علیہ", bio: "پاکپتن شریف، پاکستان۔" },
  { name: "خواجہ علاؤالدین علی احمد صابر کلیری رحمۃ اللہ علیہ", bio: "کلیر شریف، روڑکی، بھارت۔" },
  { name: "اس کے بعد کے مشائخ سے ہوتے ہوئے...", bio: "حضرت شیخ عبد القدوس گنگوہی، امام ربانی اور پیر محمد ہاشم سمنگانی سے فیضان جاری ہوا۔" },
  { name: "حضرت اخوندزادہ پیر سیف الرحمٰن مبارک رحمۃ اللہ علیہ", bio: "مزار: فقیر آباد شریف، لاہور، پاکستان۔" }
];

const SHAJRA_SUHARWARDIA: ShajraItem[] = [
  { name: "سیدنا محمد رسول اللہ ﷺ", bio: "مدینہ منورہ۔" },
  { name: "حضرت علی المرتضیٰ رضی اللہ عنہ", bio: "نجف اشرف، عراق۔" },
  { name: "حضرت حسن بصری رحمۃ اللہ علیہ", bio: "بصرہ، عراق۔" },
  { name: "حضرت حبیب عجمی رحمۃ اللہ علیہ", bio: "بصرہ، عراق۔" },
  { name: "حضرت داؤد طائی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت معروف کرخی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت سری سقطی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت جنید بغدادی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت ممشاد دینوری رحمۃ اللہ علیہ", bio: "دینور، ایران۔" },
  { name: "حضرت احمد دینوری رحمۃ اللہ علیہ", bio: "دینور، ایران۔" },
  { name: "حضرت محمد بن عبداللہ عمویہ رحمۃ اللہ علیہ", bio: "ایران۔" },
  { name: "حضرت ابو عمر قطب الدین رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت ابو النجیب عبدالقاہر سهروردی رحمۃ اللہ علیہ", bio: "بغداد، عراق۔" },
  { name: "حضرت شہاب الدین عمر سهروردی رحمۃ اللہ علیہ", bio: "بانی سلسلہ سهروردیہ۔ بغداد، عراق۔" },
  { name: "حضرت بہاؤالدین زکریا ملتانی رحمۃ اللہ علیہ", bio: "ملتان، پاکستان۔" },
  { name: "حضرت ابوالفتح رکن الدین رحمۃ اللہ علیہ", bio: "ملتان، پاکستان۔" },
  { name: "حضرت مخدوم جہانیاں جہاں گشت رحمۃ اللہ علیہ", bio: "اوچ شریف، پاکستان۔" },
  { name: "اس کے بعد کے مشائخ سے ہوتے ہوئے...", bio: "امام ربانی اور سید محمد ہاشم سمنگانی رحمۃ اللہ علیہ تک۔" },
  { name: "حضرت اخوندزادہ پیر سیف الرحمٰن مبارک رحمۃ اللہ علیہ", bio: "مزار: فقیر آباد شریف، لاہور، پاکستان۔" }
];

const ShajraList = ({ items }: { items: ShajraItem[] }) => (
  <ul className="space-y-4">
    {items.map((s, i) => (
      <li key={i} className="border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <span className="text-gold font-bold font-mono">{i + 1}.</span>
          <span className="text-xl font-bold text-white">{s.name}</span>
        </div>
        <p className="text-green-200 text-base mr-6 mt-1">{s.bio}</p>
      </li>
    ))}
  </ul>
);

const muraqabatData: MuraqabaItem[] = [
    { title: "1. مراقبہ وقوف قلب", text: "فیض می آید از ذاتِ بیچون بلطیفہ قلبی من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "2. مراقبہ وقوف روح", text: "فیض می آید از ذاتِ بیچون بلطیفہ روحی من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "3. مراقبہ وقوف سر", text: "فیض می آید از ذاتِ بیچون بلطیفہ سری من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "4. مراقبہ وقوف خفی", text: "فیض می آید از ذاتِ بیچون بلطیفہ خفی من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "5. مراقبہ وقوف اخفیٰ", text: "فیض می آید از ذاتِ بیچون بلطیفہ اخفی من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "6. مراقبہ وقوف نفسی", text: "فیض می آید از ذاتِ بیچون بلطیفہ نفسی من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "7. مراقبہ وقوف قالبی", text: "فیض می آید از ذاتِ بیچون بلطیفہ قالبی من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "8. مراقبہ وقوف خمسہ عالم امر", text: "فیض می آید از ذاتِ بیچون بلطائف خمسہ عالم امر من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "9. مراقبہ وقوف خمسہ عالم خلق", text: "فیض می آید از ذاتِ بیچون بلطائف خمسہ عالم خلق من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "10. مراقبہ مجموعہ لطائف عالم امر و عالم خلق", text: "فیض می آید از ذاتِ بیچون بہ مجموعہ لطائف عالم امر و عالم خلق من بواسطہ پیرانِ کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "11. مراقبہ احدیت", text: "فیض می آید از ذاتِ بیچون کہ جامع جمیع صفات و کمالات است و منزہ از جمیع عیوب و نقصانات است و بے مثل است بلطیفہ قلبی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "12. مراقبہ اصلِ قلب", text: "الٰہی قلب من بمقابل قلب نبی علیہ السلام۔ آں فیض تجلائے صفات فعلیہ خود کہ از قلب نبی علیہ السلام بقلب آدم علیہ السلام رسانیدہ بقلب من نیز برسانی بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "13. مراقبہ اصلِ روح", text: "الٰہی روح من بمقابل روح نبی علیہ السلام۔ آں فیض تجلائے صفات ثبوتیہ ذاتیہ حقیقیہ خود کہ از روح نبی علیہ السلام بروح نوح علیہ السلام و ابراہیم علیہ السلام رسانیدہ بروح من نیز برسانی بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "14. مراقبہ اصلِ سر", text: "الٰہی سر من بمقابل سر نبی علیہ السلام۔ آں فیض تجلائے شیونات ذاتیہ خود کہ از سر نبی علیہ السلام بسر موسیٰ علیہ السلام رسانیدہ بسر من نیز برسانی بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "15. مراقبہ اصلِ خفی", text: "الٰہی خفی من بمقابل خفی نبی علیہ السلام۔ آں فیض تجلائے صفات سلبیہ خود کہ از خفی نبی علیہ السلام بخفی عیسیٰ علیہ السلام رسانیدہ بخفی من نیز برسانی بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "16. مراقبہ اصلِ اخفیٰ", text: "الٰہی اخفائے من بمقابل اخفائے نبی علیہ السلام۔ آں فیض تجلائے شان جامع خود کہ بہ اخفائے نبی علیہ السلام رسانیدہ بہ اخفی من نیز برسانی بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "17. مراقبہ معیت", text: "فیض می آید از ذاتِ بیچون کہ ہمراہ است ہمراہِ من و بہمراہ جمیع ممکنات بلکہ ہمراہ ہر ذرہ از ذرات ممکنات بہمراہی بیچون بمفہوم ایں آیۃ کریمہ وَهُوَ مَعَكُمْ أَيْنَمَا كُنتُمْ بلطائف خمسہ عالم امر من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "18. مراقبہ اقربیت", text: "فیض می آید از ذاتِ بیچون کہ اصل اسماء و صفات است کہ نزدیک تر است از من بمن و از رگ گردن من بمن بہ نزدیکی بلاکیف بمفہوم ایں آیۃ کریمہ وَنَحْنُ أَقْرَبُ إِلَيْهِ مِنْ حَبْلِ الْوَرِيدِ بلطیفہ نفسی من باشرکت لطائف خمسہ عالم امر من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "19. مراقبہ محبت اوّل", text: "فیض می آید از ذاتِ بے چون کہ اصلِ اصلِ اسماء و صفات است کہ دوست می دارد مرا و من دوست می دارم اُو بمفہوم ایں آیۃ کریمہ يُحِبُّهُمْ وَيُحِبُّونَهُ خاص بلطیفہ نفسی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "20. مراقبہ محبت دوم", text: "فیض می آید از ذاتِ بے چون کہ اصلِ اصلِ اصلِ اسماء وصفات است کہ دوست می دارد مرا و من دوست می دارم اُو بمفہوم ایں آیۃ کریمہ يُحِبُّهُمْ وَيحِبُّونَهُ خاص بلطیفہ نفسی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "21. مراقبہ دائرہ قوس", text: "فیض می آید از ذاتِ بے چون کہ اصل اصل اصل اصل اسماء وصفات است و دائرہ قوسیت کہ دوست می دارد مرا و من دوست می دارم اُو بمفہوم ایں آیۃ کریمہ يُحِبُّهُمْ وَيُحِبُّونَهُ خاص بلطیفہ نفسی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "22. مراقبہ اسم ظاہر", text: "فیض می آید از ذاتِ بے چون کہ مسمی بہ اسم ظاہر است بمفہوم ایں آیۃ کریمہ هُوَ الْأَوَّلُ وَالْآخِرُ وَالظَّاهِرُ وَالْبَاطِنُ ۖ وَهُوَ بِكُلِّ شَيْءٍ عَلِيمٌ خاص بلطیفہ نفسی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "23. مراقبہ اسم باطن", text: "فیض می آید از ذاتِ بے چون کہ مسمی بہ اسم باطن است کہ منشاء ولایت علیا است و ولایت ملاء الاعلیٰ است بمفہوم ایں آیۃ کریمہ هُوَ الْأَوَّلُ وَالْآخِرُ وَالظَّاهِرُ وَالْبَاطِنُ ۖ وَهُوَ بِكُلِّ شَيْءٍ عَلِيمٌ بعناصر ثلاثہ من کہ آب و باد و نار است بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "24. مراقبہ کمالاتِ نبوت", text: "فیض می آید از ذاتِ بیچون کہ منشاء کمالات نبوت است بہ عنصر خاک من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "25. مراقبہ کمالاتِ رسالت", text: "فیض می آید از ذاتِ بیچون کہ منشاء کمالات رسالت است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "26. مراقبہ کمالاتِ انبیائے اولوالعزم", text: "فیض می آید از ذاتِ بیچون کہ منشاء کمالات انبیائے اولوالعزم است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "27. مراقبہ حقیقتِ کعبہ ربانی", text: "فیض می آید از ذاتِ بیچون کہ مسجود جمیع ممکنات است و منشاء حقیقت کعبہ ربانی است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "28. مراقبہ حقیقتِ قرآن مجید", text: "فیض می آید از وسعت بیچون حضرت ذات کہ منشاء حقیقت قرآن مجید است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "29. مراقبہ حقیقتِ صلوٰۃ", text: "فیض می آید از کمال وسعت بیچون حضرت ذات کہ منشاء حقیقت صلوٰۃ است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "30. مراقبہ معبودیتِ صرفہ", text: "فیض می آید از حضرت ذاتِ بیچون کہ منشاء معبودیت صرفہ است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "31. مراقبہ حقیقتِ ابراہیمی علیہ السلام", text: "فیض می آید از حضرت ذاتِ بیچون کہ محب صفات خود است و منشاء حقیقت ابراہیمی علیہ السلام است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "32. مراقبہ حقیقتِ موسوی علیہ السلام", text: "فیض می آید از حضرت ذاتِ بیچون کہ محب ذات خود است و منشاء حقیقت موسویست علیہ السلام بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "33. مراقبہ حقیقتِ محمدی ﷺ", text: "فیض می آید از حضرت ذاتِ بیچون کہ محب ذات خود است و محبوب ذات خود است و منشاء حقیقت محمد یست علیہ السلام بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "34. مراقبہ حقیقتِ احمدی ﷺ", text: "فیض می آید از ذاتِ بیچون کہ محبوب ذات خود است و منشاء حقیقت احمد یست صلی اللہ علیہ وسلم بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "35. مراقبہ حبِّ صرفہ", text: "فیض می آید از ذاتِ بیچون کہ منشاء حب صرفہ است بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" },
    { title: "36. مراقبہ لا تعین", text: "فیض می آید از ذات مطلق بیچون کہ موجود است بوجود خارجی و منزہ است از جمیع تعینات بہ ہیئت وحدانی من بواسطہ پیران کبار رحمۃ اللہ علیہم اجمعین۔" }
];

// --- Helper Components ---

const SectionTitle = ({ children }: { children: React.ReactNode }) => (
  <h2 className="text-2xl font-bold text-gold text-center border-b-2 border-dashed border-gold pb-2 mt-8 mb-4">
    {children}
  </h2>
);

interface AccordionProps {
  title: string;
  children: React.ReactNode;
  onOpen?: () => void;
  extra?: React.ReactNode;
}

const Accordion: React.FC<AccordionProps> = ({ title, children, onOpen, extra }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  const handleToggle = () => {
    const nextState = !isOpen;
    setIsOpen(nextState);
    if (nextState && onOpen) onOpen();
  };

  return (
    <div className="bg-black/60 border border-gold rounded-xl overflow-hidden mb-3 shadow-lg">
      <div className="w-full bg-gold/15 flex justify-between items-center text-gold-light font-bold text-lg text-right">
        <button 
          onClick={handleToggle}
          className="flex-1 p-4 flex justify-between items-center"
        >
          <span>{title}</span>
          {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
        {extra && <div className="pl-4">{extra}</div>}
      </div>
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="p-4 text-white leading-relaxed text-lg text-justify bg-black/50 border-t border-dashed border-gold/40">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/**
 * قرآن باکس کمپوننٹ - شیخ بندر بن بلیا
 */
const QuranBox = ({ surahNum, surahName }: { surahNum: number; surahName: string }) => {
  const [text, setText] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const audioUrl = surahNum === 78 
    ? `https://download.quranicaudio.com/quran/bandar_baleela/078.mp3`
    : `https://cdn.islamic.network/quran/audio-surah/128/ar.bandarbalila/${surahNum}.mp3`;

  // Slightly Faster Speed for Bandar Balila
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = 1.15;
    }
  }, [surahNum, isPlaying]);

  const toggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      setIsAudioLoading(true);
      
      // Robust Loading: Ensure source is assigned
      if (!audio.src || !audio.src.includes('.mp3')) {
        audio.src = audioUrl;
      }
      
      audio.playbackRate = 1.15;
      audio.play()
        .then(() => {
          setIsPlaying(true);
          setIsAudioLoading(false);
        })
        .catch(err => {
          if (err.name === 'AbortError') {
            setIsAudioLoading(false);
            return;
          }
          console.log("Audio playback error, retrying load:", err);
          // Auto-Recovery: call load() and then retry play()
          audio.load();
          audio.play()
            .then(() => {
              setIsPlaying(true);
              setIsAudioLoading(false);
            })
            .catch(retryErr => {
              if (retryErr.name === 'AbortError') {
                setIsAudioLoading(false);
                return;
              }
              console.log("Retry failed, trying backup source:", retryErr);
              // Fallback for Surah 78 if primary network blocks
              if (surahNum === 78 && !audio.src.includes('alafasy')) {
                audio.src = 'https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/78.mp3';
                audio.load();
                audio.play()
                  .then(() => {
                    setIsPlaying(true);
                    setIsAudioLoading(false);
                  })
                  .catch(() => {
                    setIsAudioLoading(false);
                    setIsPlaying(false);
                  });
              } else {
                setIsAudioLoading(false);
                setIsPlaying(false);
              }
            });
        });
    }
  };

  const fetchSurah = async () => {
    const cached = localStorage.getItem(`surah_${surahNum}`);
    if (cached && cached !== "ERROR") {
      setText(cached);
      return;
    }

    setLoading(true);
    setError(false);
    try {
      const res = await fetch(`https://api.alquran.cloud/v1/surah/${surahNum}`);
      if (!res.ok) throw new Error('API Error');
      const data = await res.json();
      if (!data.data || !data.data.ayahs) throw new Error('Invalid Data');
      const fullText = data.data.ayahs.map((a: any) => a.text).join('  ');
      localStorage.setItem(`surah_${surahNum}`, fullText);
      setText(fullText);
    } catch (err) {
      console.error(`Fetch error for Surah ${surahNum}:`, err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative">
      <audio 
        ref={audioRef} 
        src={audioUrl}
        onPlay={() => {
          setIsPlaying(true);
          setIsAudioLoading(false);
          if (audioRef.current) audioRef.current.playbackRate = 1.15;
        }}
        onPause={() => setIsPlaying(false)}
        onEnded={() => setIsPlaying(false)}
        onWaiting={() => setIsAudioLoading(true)}
        onCanPlay={() => setIsAudioLoading(false)}
        onError={() => {
          const audio = audioRef.current;
          if (audio && surahNum === 78 && !audio.dataset.retried) {
            audio.dataset.retried = 'true';
            audio.src = 'https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/78.mp3';
            audio.load();
          }
        }}
        preload="metadata"
        playsInline
      />
      <Accordion 
        title={surahName} 
        onOpen={fetchSurah}
        extra={
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleAudio}
              disabled={isAudioLoading}
              className={cn(
                "p-2 rounded-full transition-all flex items-center justify-center",
                isPlaying ? "bg-gold text-black scale-110" : "bg-gold/20 text-gold hover:bg-gold/40",
                isAudioLoading && "opacity-50 cursor-wait"
              )}
              title={isPlaying ? "روکیں" : "سنیں (شیخ بندر بن بلیا)"}
            >
              {isAudioLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : isPlaying ? (
                <Pause className="w-4 h-4" />
              ) : (
                <Play className="w-4 h-4" />
              )}
            </button>
          </div>
        }
      >
        <div className="max-height-[400px] overflow-y-auto quran-box">
          <div className="flex flex-col items-center mb-4 gap-2">
            <div className="bg-gold/10 border border-gold/30 rounded-lg px-4 py-2 flex items-center gap-2 text-gold-light text-sm">
              <Volume2 className="w-4 h-4" />
              <span>تلاوت: شیخ بندر بن بلیا</span>
            </div>
          </div>
          {loading && <div className="text-center text-green-300 py-4">لوڈ ہو رہا ہے...</div>}
          {error && <div className="text-center text-red-400 py-4">انٹرنیٹ کا مسئلہ ہے۔</div>}
          {text && <span className="arabic-text text-2xl text-gold-light leading-[2.2] block text-center drop-shadow-md">{text}</span>}
        </div>
      </Accordion>
    </div>
  );
};

// --- Error Boundary ---
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error: any }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black flex items-center justify-center p-6 text-center" dir="rtl">
          <div className="bg-red-900/20 border-2 border-red-500 p-8 rounded-3xl max-w-md">
            <h1 className="text-2xl font-bold text-red-400 mb-4">ایپ میں خرابی آگئی ہے</h1>
            <p className="text-gray-300 mb-6">براہ کرم پیج کو ریفریش کریں یا تھوڑی دیر بعد کوشش کریں۔</p>
            <button 
              onClick={() => window.location.reload()}
              className="bg-red-600 text-white px-6 py-2 rounded-full font-bold hover:bg-red-700 transition-colors"
            >
              ریفریش کریں
            </button>
            {import.meta.env.DEV && (
              <pre className="mt-4 text-xs text-red-300 text-left overflow-auto max-h-40 p-2 bg-black/50 rounded">
                {this.state.error?.toString()}
              </pre>
            )}
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Main App Component ---

function MainApp() {
  const [location, setLocation] = useState<LocationData>({
    city: "گوجرخان",
    lat: 33.2612,
    lon: 73.3058,
    timezone: "Asia/Karachi"
  });
  const [currentTime, setCurrentTime] = useState(new Date());
  const [atomicOffset, setAtomicOffset] = useState(0);
  const [prayerTimes, setPrayerTimes] = useState<PrayerTimes | null>(null);
  const [nextPrayer, setNextPrayer] = useState<{ name: string; countdown: string } | null>(null);
  const [apiStatus, setApiStatus] = useState({ text: "کنیکٹ ہو رہا ہے...", color: "text-green-400" });
  const [showCityInput, setShowCityInput] = useState(false);
  const [tempCity, setTempCity] = useState("");
  const [isAzanEnabled, setIsAzanEnabled] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('saifi_azan_enabled') === 'true';
    }
    return false;
  });
  const [isTahajjudAlarmEnabled, setIsTahajjudAlarmEnabled] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('saifi_tahajjud_enabled') === 'true';
    }
    return false;
  });
  const [lastPlayedAzan, setLastPlayedAzan] = useState("");
  const [lastPlayedTahajjud, setLastPlayedTahajjud] = useState("");
  const azanAudioRef = useRef<HTMLAudioElement | null>(null);
  const tahajjudAudioRef = useRef<HTMLAudioElement | null>(null);

  const toggleAzan = () => {
    const newValue = !isAzanEnabled;
    setIsAzanEnabled(newValue);
    localStorage.setItem('saifi_azan_enabled', newValue.toString());
    // Play a short silent sound to unlock audio context
    const audio = azanAudioRef.current;
    if (newValue && audio) {
      audio.load();
      audio.play().then(() => {
        audio.pause();
        audio.currentTime = 0;
      }).catch(() => {
        // Silent catch for unlock attempt
      });
    }
  };

  const toggleTahajjudAlarm = () => {
    const newValue = !isTahajjudAlarmEnabled;
    setIsTahajjudAlarmEnabled(newValue);
    localStorage.setItem('saifi_tahajjud_enabled', newValue.toString());
    
    const audio = tahajjudAudioRef.current;
    if (audio) {
      if (newValue) {
        // Force load and play a short silent sound to unlock audio context
        audio.load();
        audio.play().then(() => {
          audio.pause();
          audio.currentTime = 0;
        }).catch(() => {
          // Silent catch for unlock attempt
        });
      } else {
        // Stop audio if disabled
        audio.pause();
        audio.currentTime = 0;
      }
    }
  };

  const testAzan = (e: React.MouseEvent) => {
    e.preventDefault();
    const audio = azanAudioRef.current;
    if (audio) {
      if (!audio.paused) {
        audio.pause();
        audio.currentTime = 0;
      } else {
        audio.load();
        audio.play().catch(err => {
          if (err.name === 'AbortError') {
            console.log("Azan play request was interrupted (normal).");
          } else {
            console.error("Azan test failed:", err);
            alert("اذان کی آواز نہیں چل سکی۔ براہ کرم انٹرنیٹ چیک کریں۔");
          }
        });
      }
    }
  };

  const testTahajjud = (e: React.MouseEvent) => {
    e.preventDefault();
    const audio = tahajjudAudioRef.current;
    if (audio) {
      if (!audio.paused) {
        audio.pause();
        audio.currentTime = 0;
      } else {
        audio.load();
        audio.play().catch(err => {
          if (err.name === 'AbortError') {
            console.log("Tahajjud play request was interrupted (normal).");
          } else {
            console.error("Tahajjud test failed:", err);
            alert("الارم کی آواز نہیں چل سکی۔ براہ کرم انٹرنیٹ چیک کریں۔");
          }
        });
      }
    }
  };

  // --- Clock & Sync ---
  useEffect(() => {
    const syncTime = async () => {
      try {
        const res = await fetch('https://timeapi.io/api/Time/current/zone?timeZone=UTC');
        const data = await res.json();
        const offset = new Date(data.dateTime + "Z").getTime() - Date.now();
        setAtomicOffset(offset);
        setApiStatus({ text: "🟢 لائیو سٹینڈرڈ ٹائم", color: "text-green-400" });
      } catch (e) {
        setApiStatus({ text: "🔴 ڈیوائس ٹائم", color: "text-red-400" });
      }
    };
    syncTime();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date(Date.now() + atomicOffset);
      setCurrentTime(now);

      // Auto Azan Logic
      if (isAzanEnabled && prayerTimes) {
        const tz = location.timezone || "Asia/Karachi";
        let nowTimeStr = "00:00:00";
        try {
          nowTimeStr = formatInTimeZone(now, tz, 'HH:mm:ss');
        } catch (e) {
          nowTimeStr = formatInTimeZone(now, "Asia/Karachi", 'HH:mm:ss');
        }

        const currentMinute = nowTimeStr.substring(0, 5);
        if (currentMinute !== lastPlayedAzan) {
          const azanTimes = [
            prayerTimes.Fajr,
            prayerTimes.Dhuhr,
            prayerTimes.Asr,
            prayerTimes.Maghrib,
            prayerTimes.Isha
          ];

          if (azanTimes.includes(currentMinute)) {
            if (azanAudioRef.current) {
              azanAudioRef.current.play()
                .then(() => setLastPlayedAzan(currentMinute))
                .catch(e => console.warn("Azan playback blocked", e));
            }
          }
        }
      }

      // Tahajjud Alarm Logic (30 mins before Fajr)
      if (isTahajjudAlarmEnabled && prayerTimes && prayerTimes.Fajr) {
        const tz = location.timezone || "Asia/Karachi";
        let nowTimeStr = "00:00:00";
        try {
          nowTimeStr = formatInTimeZone(now, tz, 'HH:mm:ss');
        } catch (e) {
          nowTimeStr = formatInTimeZone(now, "Asia/Karachi", 'HH:mm:ss');
        }

        const currentMinute = nowTimeStr.substring(0, 5);
        if (currentMinute !== lastPlayedTahajjud) {
          const tahajjudTime = addMins(prayerTimes.Fajr, -30);
          if (tahajjudTime === currentMinute) {
            if (tahajjudAudioRef.current) {
              tahajjudAudioRef.current.play()
                .then(() => setLastPlayedTahajjud(currentMinute))
                .catch(e => console.warn("Tahajjud alarm playback blocked", e));
            }
          }
        }
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [atomicOffset, isAzanEnabled, isTahajjudAlarmEnabled, prayerTimes, location.timezone, lastPlayedAzan, lastPlayedTahajjud]);

  // --- Location & Prayer Times ---
  const reverseGeocode = async (lat: number, lon: number) => {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&accept-language=ur,en`);
      const data = await res.json();
      if (data && data.address) {
        const city = data.address.city || data.address.town || data.address.village || data.address.suburb || data.address.county || "نامعلوم مقام";
        return city;
      }
      return null;
    } catch (e) {
      return null;
    }
  };

  const fetchPrayerTimes = useCallback(async (lat: number, lon: number) => {
    try {
      const res = await fetch(`https://api.aladhan.com/v1/timings?latitude=${lat}&longitude=${lon}&method=1&school=1`);
      const data = await res.json();
      if (data && data.data) {
        setPrayerTimes(data.data.timings);
        if (data.data.meta && data.data.meta.timezone) {
          setLocation(prev => ({ ...prev, timezone: data.data.meta.timezone }));
        }
      }
    } catch (e) {
      console.error("Failed to fetch prayer times", e);
    }
  }, []);

  const detectLocation = useCallback(async (force = false) => {
    setApiStatus({ text: "لوکیشن تلاش کی جا رہی ہے...", color: "text-gold" });

    const fallbackToIp = async () => {
      try {
        const res = await fetch('https://get.geojs.io/v1/ip/geo.json');
        const data = await res.json();
        if (data.latitude && data.longitude) {
          const lat = parseFloat(data.latitude);
          const lon = parseFloat(data.longitude);
          const cityName = await reverseGeocode(lat, lon) || data.city || "نامعلوم مقام";
          
          setLocation(prev => ({ ...prev, city: cityName, lat, lon }));
          localStorage.setItem('saifi_city', cityName);
          localStorage.setItem('saifi_lat', lat.toString());
          localStorage.setItem('saifi_lon', lon.toString());
          fetchPrayerTimes(lat, lon);
          setApiStatus({ text: "🟢 لوکیشن (IP) سے اپڈیٹ", color: "text-green-400" });
        } else {
          fetchPrayerTimes(location.lat, location.lon);
        }
      } catch (e) {
        fetchPrayerTimes(location.lat, location.lon);
      }
    };

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          const cityName = await reverseGeocode(latitude, longitude);
          const finalCity = cityName || "آپ کا مقام";
          
          setLocation(prev => ({ ...prev, city: finalCity, lat: latitude, lon: longitude }));
          localStorage.setItem('saifi_city', finalCity);
          localStorage.setItem('saifi_lat', latitude.toString());
          localStorage.setItem('saifi_lon', longitude.toString());
          fetchPrayerTimes(latitude, longitude);
          setApiStatus({ text: "🟢 لوکیشن GPS سے اپڈیٹ", color: "text-green-400" });
        },
        (error) => {
          console.warn("Geolocation failed", error);
          fallbackToIp();
        },
        { timeout: 10000, enableHighAccuracy: true }
      );
    } else {
      fallbackToIp();
    }
  }, [fetchPrayerTimes, location.lat, location.lon]);

  // Initial load effect
  useEffect(() => {
    const init = async () => {
      const cachedLat = localStorage.getItem('saifi_lat');
      const cachedLon = localStorage.getItem('saifi_lon');
      const cachedCity = localStorage.getItem('saifi_city');

      if (cachedLat && cachedLon && cachedCity) {
        const lat = parseFloat(cachedLat);
        const lon = parseFloat(cachedLon);
        setLocation(prev => ({ ...prev, city: cachedCity, lat, lon }));
        fetchPrayerTimes(lat, lon);
      } else {
        detectLocation();
      }
    };
    init();
  }, []); // Run only once on mount

  // --- Countdown Logic ---
  useEffect(() => {
    if (!prayerTimes) return;

    const updateCountdown = () => {
      const tz = location.timezone || "Asia/Karachi";
      const now = new Date(Date.now() + atomicOffset);
      let nowTimeStr = "00:00:00";
      try {
        nowTimeStr = formatInTimeZone(now, tz, 'HH:mm:ss');
      } catch (e) {
        console.error("Timezone error", e);
        nowTimeStr = formatInTimeZone(now, "Asia/Karachi", 'HH:mm:ss');
      }
      const currentD = new Date(`1970-01-01T${nowTimeStr}Z`);

      const addMinutes = (timeStr: string, mins: number) => {
        const [h, m] = timeStr.split(':');
        const d = new Date();
        d.setHours(parseInt(h), parseInt(m), 0);
        d.setMinutes(d.getMinutes() + mins);
        return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
      };

      const timesList = [
        { name: 'فجر', time: new Date(`1970-01-01T${prayerTimes.Fajr}:00Z`) },
        { name: 'طلوعِ آفتاب', time: new Date(`1970-01-01T${prayerTimes.Sunrise}:00Z`) },
        { name: 'اشراق', time: new Date(`1970-01-01T${addMinutes(prayerTimes.Sunrise, 15)}:00Z`) },
        { name: 'چاشت', time: new Date(`1970-01-01T${addMinutes(prayerTimes.Sunrise, 45)}:00Z`) },
        { name: 'زوال', time: new Date(`1970-01-01T${addMinutes(prayerTimes.Dhuhr, -10)}:00Z`) },
        { name: 'ظہر', time: new Date(`1970-01-01T${prayerTimes.Dhuhr}:00Z`) },
        { name: 'عصر', time: new Date(`1970-01-01T${prayerTimes.Asr}:00Z`) },
        { name: 'مغرب', time: new Date(`1970-01-01T${prayerTimes.Maghrib}:00Z`) },
        { name: 'عشاء', time: new Date(`1970-01-01T${prayerTimes.Isha}:00Z`) }
      ];

      let nextP = timesList.find(p => currentD < p.time);
      if (!nextP) {
        nextP = { name: 'فجر (اگلا دن)', time: new Date(timesList[0].time.getTime() + 24 * 60 * 60 * 1000) };
      }

      const diff = nextP.time.getTime() - currentD.getTime();
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);

      setNextPrayer({
        name: nextP.name,
        countdown: `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
      });
    };

    const interval = setInterval(updateCountdown, 1000);
    updateCountdown();
    return () => clearInterval(interval);
  }, [prayerTimes, atomicOffset, location.timezone]);

  const handleCityChange = async (newCity: string) => {
    if (!newCity || newCity === location.city) return;

    try {
      setApiStatus({ text: "شہر تلاش کیا جا رہا ہے...", color: "text-gold" });
      const res = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(newCity)}&format=json&limit=1`);
      const data = await res.json();
      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        const cityName = data[0].display_name.split(',')[0];
        
        setLocation(prev => ({ ...prev, city: cityName, lat, lon }));
        localStorage.setItem('saifi_city', cityName);
        localStorage.setItem('saifi_lat', lat.toString());
        localStorage.setItem('saifi_lon', lon.toString());
        fetchPrayerTimes(lat, lon);
        setApiStatus({ text: `🟢 شہر تبدیل: ${cityName}`, color: "text-green-400" });
        setShowCityInput(false);
      } else {
        setApiStatus({ text: "🔴 شہر نہیں ملا۔", color: "text-red-400" });
      }
    } catch (e) {
      console.error("Failed to search city", e);
      setApiStatus({ text: "🔴 انٹرنیٹ کا مسئلہ ہے۔", color: "text-red-400" });
    }
  };

  const formatTime = (timeStr: string | undefined) => {
    if (!timeStr) return "--:--";
    const [h, m] = timeStr.split(':');
    let hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 12 || 12;
    return `${String(hour).padStart(2, '0')}:${m} ${ampm}`;
  };

  const addMins = (timeStr: string | undefined, mins: number) => {
    if (!timeStr) return undefined;
    const [h, m] = timeStr.split(':');
    const d = new Date();
    d.setHours(parseInt(h), parseInt(m), 0);
    d.setMinutes(d.getMinutes() + mins);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen flex flex-col items-center pb-12 px-4" dir="rtl">
      {/* Header */}
      <header className="w-full bg-gradient-to-br from-black/85 to-gold/10 border-b-4 border-gold rounded-b-[40px] py-10 text-center shadow-2xl mb-8 relative">
        <h1 className="text-gold text-6xl md:text-7xl font-nastaleeq drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] leading-tight">سلسلہ سیفیہ</h1>
        <div className="mt-4 text-gold-light/90 text-xl md:text-2xl font-nastaleeq tracking-wide">
          نقشبندیہ • چشتیہ • قادریہ • سہروردیہ
        </div>
      </header>

      <main className="w-full max-w-[600px] flex flex-col gap-5">
        
        {/* Status Box */}
        <section className="bg-black/60 p-5 rounded-2xl border border-gold shadow-xl text-center">
          <div className="flex flex-wrap justify-center items-center gap-2 mb-3">
            <div className="inline-flex items-center gap-2 bg-gold/20 text-gold-light px-4 py-1.5 rounded-full text-xl border border-gold/50">
              <MapPin className="w-5 h-5" />
              <span>{location.city}</span>
              <button 
                onClick={() => setShowCityInput(true)} 
                title="شہر تبدیل کریں"
                className="bg-gold text-black rounded-full p-1 hover:bg-gold-light transition-colors"
              >
                <Edit2 className="w-3 h-3" />
              </button>
            </div>
            <button 
              onClick={() => detectLocation(true)} 
              title="خودکار لوکیشن"
              className="bg-green-600/30 text-green-400 border border-green-500/50 rounded-full p-2 hover:bg-green-600/50 transition-all flex items-center gap-1 text-sm font-bold"
            >
              <Zap className="w-4 h-4" />
              <span>آٹو</span>
            </button>
          </div>

          {showCityInput && (
            <div className="mb-4 flex gap-2 justify-center">
              <input 
                type="text" 
                placeholder="شہر کا نام..." 
                className="bg-black/50 border border-gold rounded-lg px-3 py-1 text-white text-sm"
                value={tempCity}
                onChange={(e) => setTempCity(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleCityChange(tempCity)}
              />
              <button 
                onClick={() => handleCityChange(tempCity)}
                className="bg-gold text-black px-3 py-1 rounded-lg text-sm font-bold"
              >
                اوکے
              </button>
              <button 
                onClick={() => setShowCityInput(false)}
                className="bg-red-900/50 text-white px-3 py-1 rounded-lg text-sm"
              >
                کینسل
              </button>
            </div>
          )}
          <div className="text-lg mb-1 text-gray-300">
            {(() => {
              try {
                const gregDate = formatInTimeZone(currentTime, location.timezone || "Asia/Karachi", 'EEEE, d MMMM yyyy');
                
                // Manual Hijri Calculation (Tabular Islamic Calendar)
                const hijriMonths = [
                  "محرم", "صفر", "ربیع الاول", "ربیع الثانی", "جمادی الاول", "جمادی الثانی",
                  "رجب", "شعبان", "رمضان", "شوال", "ذوالقعدہ", "ذوالحجہ"
                ];
                
                const m = currentTime.getMonth() + 1;
                const y = currentTime.getFullYear();
                const d = currentTime.getDate();

                const jd = Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + (2 - Math.floor(y / 100) + Math.floor(Math.floor(y / 100) / 4)) - 1524.5;
                
                const ijd = Math.floor(jd) - 1948440 + 10632; 
                const n = Math.floor((ijd - 1) / 10631);
                const l = ijd - 10631 * n + 354;
                const j = (Math.floor((10985 - l) / 5316)) * (Math.floor((50 * l) / 17719)) + (Math.floor(l / 5670)) * (Math.floor((43 * l) / 15238));
                const k = l - (Math.floor((30 - j) / 15)) * (Math.floor((17719 * j) / 50)) - (Math.floor(j / 16)) * (Math.floor((15238 * j) / 43)) + 29;
                const hMonthIdx = Math.floor((24 * k) / 709);
                const hDay = k - Math.floor((709 * hMonthIdx) / 24);
                const hYear = 30 * n + j - 30;
                
                const hijriDate = `${hDay} ${hijriMonths[hMonthIdx - 1]} ${hYear}ھ`;

                return (
                  <div className="flex flex-col gap-1">
                    <span>{gregDate}</span>
                    <span className="text-gold-light font-bold text-2xl">{hijriDate}</span>
                  </div>
                );
              } catch (e) {
                return (
                  <div className="flex flex-col gap-1">
                    <span>{formatInTimeZone(currentTime, "Asia/Karachi", 'EEEE, d MMMM yyyy')}</span>
                  </div>
                );
              }
            })()}
          </div>
          <div className="text-4xl font-bold font-mono tracking-tight text-white ltr">
            {(() => {
              try {
                return formatInTimeZone(currentTime, location.timezone || "Asia/Karachi", 'hh:mm:ss a');
              } catch (e) {
                return formatInTimeZone(currentTime, "Asia/Karachi", 'hh:mm:ss a');
              }
            })()}
          </div>
          <div className={cn("text-sm mt-2 font-medium", apiStatus.color)}>
            {apiStatus.text}
          </div>
        </section>

        {/* Next Prayer Box */}
        <section className="bg-gradient-to-br from-[#003214] to-[#001a0a] border-2 border-gold-light rounded-2xl p-5 text-center shadow-xl">
          <div className="text-xl text-gold-light mb-1 font-bold">
            {nextPrayer?.name || "اگلا وقت: --"}
          </div>
          <div className="text-5xl font-bold text-gold font-mono tracking-[4px] ltr">
            {nextPrayer?.countdown || "00:00:00"}
          </div>
        </section>

        {/* Prayer Times Grid */}
        <div className="flex flex-wrap justify-center gap-3 mb-4">
          <div className="flex flex-col items-center gap-1">
            <button 
              onClick={toggleAzan}
              className={cn(
                "flex items-center gap-3 px-6 py-2.5 rounded-full border-2 transition-all duration-300 font-bold text-lg shadow-lg",
                isAzanEnabled 
                  ? "bg-green-900/40 border-gold text-gold-light shadow-[0_0_20px_rgba(212,175,55,0.2)]" 
                  : "bg-black/40 border-gray-800 text-gray-500"
              )}
            >
              <span className="text-2xl">{isAzanEnabled ? "🔔" : "🔕"}</span>
              <span>{isAzanEnabled ? "اذان: آن" : "اذان: آف"}</span>
            </button>
            <button onClick={testAzan} className="text-[10px] text-gold-light/50 hover:text-gold-light underline">ٹیسٹ اذان (آن/آف)</button>
          </div>

          <div className="flex flex-col items-center gap-1">
            <button 
              onClick={toggleTahajjudAlarm}
              className={cn(
                "flex items-center gap-3 px-6 py-2.5 rounded-full border-2 transition-all duration-300 font-bold text-lg shadow-lg",
                isTahajjudAlarmEnabled 
                  ? "bg-blue-900/40 border-blue-400 text-blue-200 shadow-[0_0_20px_rgba(96,165,250,0.2)]" 
                  : "bg-black/40 border-gray-800 text-gray-500"
              )}
            >
              <span className="text-2xl">{isTahajjudAlarmEnabled ? "⏰" : "💤"}</span>
              <span>{isTahajjudAlarmEnabled ? "تہجد الارم: آن" : "تہجد الارم: آف"}</span>
            </button>
            <button onClick={testTahajjud} className="text-[10px] text-blue-400/50 hover:text-blue-400 underline">ٹیسٹ الارم (آن/آف)</button>
          </div>
        </div>
        <SectionTitle>اوقاتِ نماز (فقہ حنفی)</SectionTitle>
        <div className="grid grid-cols-3 gap-2 text-center">
          {[
            { name: 'فجر', time: formatTime(prayerTimes?.Fajr), icon: <Sunrise className="w-4 h-4" /> },
            { name: 'طلوعِ آفتاب', time: formatTime(prayerTimes?.Sunrise), special: true },
            { name: 'اشراق', time: formatTime(addMins(prayerTimes?.Sunrise, 15)), special: true },
            { name: 'چاشت', time: formatTime(addMins(prayerTimes?.Sunrise, 45)), special: true },
            { name: 'زوال', time: formatTime(addMins(prayerTimes?.Dhuhr, -10)), special: true },
            { name: 'ظہر', time: formatTime(prayerTimes?.Dhuhr), icon: <Sun className="w-4 h-4" /> },
            { name: 'عصر', time: formatTime(prayerTimes?.Asr) },
            { name: 'مغرب', time: formatTime(prayerTimes?.Maghrib), icon: <Sunset className="w-4 h-4" /> },
            { name: 'عشاء', time: formatTime(prayerTimes?.Isha), icon: <Moon className="w-4 h-4" /> },
            { name: 'تہجد', time: 'عشاء سے فجر تک', special: true, span: 2 }
          ].map((p, i) => (
            <div 
              key={i} 
              className={cn(
                "bg-black/60 border border-gold rounded-xl p-3 flex flex-col items-center justify-center gap-1",
                p.special && "bg-gold/10",
                p.span === 2 && "col-span-2"
              )}
            >
              <span className="text-gold-light text-lg font-bold flex items-center gap-1">
                {p.icon} {p.name}
              </span>
              <span className="text-white text-base font-mono ltr">{p.time}</span>
            </div>
          ))}
        </div>

        {/* Quranic Surahs */}
        <SectionTitle>قرآنی سورتیں (معمولات)</SectionTitle>
        <QuranBox surahNum={36} surahName="نماز فجر (سورہ یٰسین)" />
        <QuranBox surahNum={48} surahName="نماز ظہر (سورہ فتح)" />
        <QuranBox surahNum={78} surahName="نماز عصر (سورہ نبا)" />
        <QuranBox surahNum={56} surahName="نماز مغرب (سورہ واقعہ)" />
        <QuranBox surahNum={67} surahName="نماز عشاء (سورہ ملک)" />
        <QuranBox surahNum={18} surahName="جمعہ کے دن (سورہ کہف)" />

        {/* Khatm Section */}
        <SectionTitle>ختم خواجگان</SectionTitle>
        <Accordion title="مکمل طریقہ ختم خواجگان">
          <span className="arabic-text text-xl block text-center mb-4 text-gold-light">اَلْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمِيْنَ وَالصَّلٰوةُ وَالسَّلَامُ عَلٰى رَسُوْلِهِ الْكَرِيْمِ ؕ رَبَّنَا تَقَبَّلْ مِنَّا إِنَّكَ أَنْتَ السَّمِيعُ الْعَلِيمُ وَتُبْ عَلَيْنَا إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ ؕ وصلى الله تعالى على حبيبه محمد وآله اصحابه اجمعين</span>
          <ul className="space-y-3 pr-4 border-r-2 border-gold/30">
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">فاتحہ شریف <span className="text-gold-light">(7 مرتبہ)</span></li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">استغفار <span className="text-gold-light">(100 مرتبہ)</span>: <br/><span className="text-gold-light font-bold">اَسْتَغْفِرُ اللّٰہَ رَبِّی مِنْ کُلِّ ذَنْۢبٍ وَّاَتُوْبُ اِلَیْہِ</span></li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">درود شریف <span className="text-gold-light">(100 مرتبہ)</span></li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">الم نشرح <span className="text-gold-light">(79 مرتبہ)</span></li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">سورہ اخلاص <span className="text-gold-light">(1000 یا 100 مرتبہ)</span></li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">فاتحہ شریف <span className="text-gold-light">(7 مرتبہ)</span></li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">درود شریف <span className="text-gold-light">(100 مرتبہ)</span></li>
          </ul>
        </Accordion>
        {KHATMS.map((k, i) => (
          <Accordion key={i} title={k.name}>
            <ul className="space-y-3 pr-4 border-r-2 border-gold/30">
              <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">درود شریف <span className="text-gold-light">(100 مرتبہ)</span></li>
              <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
                <span className="arabic-text text-xl text-gold-light">{k.zikr}</span> <span className="text-gold-light">(500 مرتبہ)</span>
              </li>
              <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">درود شریف <span className="text-gold-light">(100 مرتبہ)</span></li>
            </ul>
          </Accordion>
        ))}

        {/* Istilahaat */}
        <SectionTitle>اصطلاحاتِ نقشبندیہ</SectionTitle>
        <Accordion title="12 اصطلاحاتِ طریقت">
          <div className="grid grid-cols-1 gap-3">
            {[
              { t: "1. نَظَر بَر قَدَم", d: "سالک چلتے وقت اپنی نظر قدم پر رکھے۔ اس سے جمعیتِ باطن حاصل ہوتی ہے اور انتشار سے محفوظ رہتا ہے۔" },
              { t: "2. ہُوش دَر دَم", d: "سالک ہر سانس میں ہوشیار رہے کہ وہ ذاکر ہے یا غافل۔ (اسے وقوف زمانی بھی کہتے ہیں)" },
              { t: "3. سَفَر دَر وَطَن", d: "یہ سیرِ نفسی کا نام ہے۔ سالک اپنے نفس میں غور کرے کہ کیا غیر اللہ کی محبت باقی ہے یا نہیں، اگر ہو تو توبہ کرے۔" },
              { t: "4. خَلْوَت دَر اَنْجُمَن", d: "سالک انجمن (محفل) کو بھی خلوت خانہ بنائے اور ظاہری تفرقے سے اس کا باطن متاثر نہ ہو۔" },
              { t: "5. یَاد کَرْد", d: "اس سے مراد اللہ تعالیٰ کا ذکر ہے، چاہے اسمِ ذات کا ہو یا نفی اثبات کا۔" },
              { t: "6. بَازْگَشْت", d: "چند بار ذکر کرنے کے بعد اللہ تعالیٰ سے اس کی رضا طلب کرنے کی مناجات کرتا رہے۔" },
              { t: "7. نِگَاہ دَاشْت", d: "سالک کو چاہیے کہ ہوشیار رہے اور دل میں خطرات اور وساوس کو نہ آنے دے۔" },
              { t: "8. یَاد دَاشْت", d: "اللہ تعالیٰ کے لئے توجہِ صرف جو الفاظ و تخیلات سے مجرد ہو اور حضور بے غیبت ہو۔" },
              { t: "9. وُقُوفِ عَدَدِی", d: "نفی اثبات کے ذکر میں طاق عدد کی رعایت کو کہتے ہیں۔" },
              { t: "10. وُقُوفِ قَلْبِی", d: "قلب کی طرف کامل توجہ کرنے کو کہتے ہیں۔" },
              { t: "11. فَنَاء", d: "ماسوا اللہ کا بھول جانا فنا ہے۔ اس طرح کہ صرف وجودِ حقیقی مستحضر رہے۔" },
              { t: "12. بَقَاء", d: "کامل فنا کے بعد دوسروں کی ہدایت کیلئے نسیان شدہ اشیاء کی طرف لوٹ آنا بقاء کہلاتی ہے۔" }
            ].map((item, i) => (
              <div key={i} className="bg-black/40 border border-gold/30 p-4 rounded-xl">
                <span className="text-gold-light font-bold text-xl block mb-1">{item.t}</span>
                <p className="text-gray-200">{item.d}</p>
              </div>
            ))}
          </div>
        </Accordion>

        {/* Latifa Section */}
        <SectionTitle>اسباق طریقہ نقشبندیہ</SectionTitle>
        {[
          { id: 'qalb', icon: '💛', name: 'لطیفہ قلب', color: 'رنگ: زرد | مقام: بائیں پستان کے نیچے دو انگل', prophet: 'مقامِ فیض: حضرت آدم علیہ السلام', effect: 'ماسوا اللہ کے نسیان اور ذاتِ حق کے ساتھ محویت۔ دافعِ غفلت اور دافعِ شہوت ہے۔', border: 'border-yellow-500' },
          { id: 'ruh', icon: '❤️', name: 'لطیفہ روح', color: 'رنگ: سرخ | مقام: دائیں پستان کے نیچے دو انگل', prophet: 'مقامِ فیض: حضرت نوحؑ و حضرت ابراہیمؑ', effect: 'اسم ذات کی صفاتی تجلیات کا ظہور۔ غصہ و غضب کی کیفیت میں اعتدال اور طبیعت میں سکون پیدا ہوتا ہے۔', border: 'border-red-500' },
          { id: 'sirr', icon: '🤍', name: 'لطیفہ سرّ', color: 'رنگ: سفید | مقام: بائیں پستان کے اوپر دو انگل', prophet: 'مقامِ فیض: حضرت موسیٰ علیہ السلام', effect: 'یہ مشاہدہ اور دیدار کا مقام ہے۔ حرص کا خاتمہ اور دینی معاملات میں فیاضی پیدا ہوتی ہے۔', border: 'border-white' },
          { id: 'khafi', icon: '🖤', name: 'لطیفہ خفی', color: 'رنگ: سیاہ | مقام: دائیں پستان کے اوپر دو انگل', prophet: 'مقامِ فیض: حضرت عیسیٰ علیہ السلام', effect: 'حسد، بخل، کینہ، غیبت وغیرہ سے مکمل نجات حاصل ہوتی ہے۔', border: 'border-slate-800' },
          { id: 'akhfa', icon: '💚', name: 'لطیفہ اخفیٰ', color: 'رنگ: سبز | مقام: سینے کے بالکل درمیان میں', prophet: 'مقامِ فیض: سید الانبیاء حضرت محمد ﷺ', effect: 'بلا تکلف ذکر جاری ہوتا ہے۔ تکبر، فخر و غرور اور خود پسندی سے نجات حاصل ہوتی ہے۔', border: 'border-green-500' },
          { id: 'nafsi', icon: '🤎', name: 'لطیفہ نفس', color: 'رنگ: مٹیالا | مقام: پیشانی / ماتھا', prophet: 'تزکیہ نفس اور قلب کا رابطہ', effect: 'نفسانیت و سرکشی مٹ جاتی ہے۔ عجز و انکساری پیدا ہوتی ہے اور ذوق و شوق بڑھ جاتا ہے۔', border: 'border-amber-800' },
          { id: 'qalabi', icon: '✨', name: 'لطیفہ قالب', color: 'رنگ: تمام رنگوں کا مجموعہ | مقام: سارا جسم', prophet: 'جسم کے ہر بال اور قطرے سے ذکر', effect: 'اس کی تاثیر تمام بدن میں ظاہر ہوتی ہے۔ رذائل بشریہ اور علائق دنیویہ سے مکمل رہائی ملتی ہے۔', border: 'border-gold' }
        ].map((l, i) => (
          <div key={i} className={cn("bg-black/80 rounded-2xl p-5 flex flex-col shadow-xl border-r-8 mb-4", l.border)}>
            <div className="flex items-center border-b border-white/10 pb-3 mb-3">
              <span className="text-4xl ml-4">{l.icon}</span>
              <div className="flex-1">
                <div className="text-2xl font-bold text-white">{l.name}</div>
                <span className="text-sm text-gray-400">{l.color}</span>
              </div>
            </div>
            <div className="text-lg text-gold font-bold mb-1">{l.prophet}</div>
            <p className="text-base text-green-200 leading-relaxed">
              <strong className="text-gold-light ml-1">تاثیر:</strong> {l.effect}
            </p>
          </div>
        ))}

        <Accordion title="ذکر نفی اثبات">
          <p className="mb-3">ساتوں لطائف کے بعد طاق عدد پر حبسِ نفس (سانس روک کر) ذکر کیا جاتا ہے۔</p>
          <ul className="space-y-2 pr-4 border-r-2 border-gold/30 mb-4">
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">زبان کو تالو سے لگا کر سانس ناف کے نیچے روکیں۔</li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">'لا' کو ناف سے کھینچ کر دماغ تک لے جائیں۔</li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">'إله' دماغ سے دائیں کندھے تک لائیں۔</li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">'إلا الله' کی ضرب پوری قوت سے قلب (دل) پر لگائیں۔</li>
          </ul>
          <div className="text-center">
            <span className="text-gold font-bold block mb-2">نیت (قلب پر ضرب کے وقت):</span>
            <span className="arabic-text text-2xl text-gold-light block leading-relaxed">"إِلٰهِي أَنْتَ مَقْصُودِيْ وَرِضَاكَ مَطْلُوبِيْ، أَعْطِنِيْ مَحَبَّةَ ذَاتِكَ وَمَعْرِفَةَ صِفَاتِكَ"</span>
          </div>
        </Accordion>

        {/* Muraqabat */}
        <SectionTitle>معمولاتِ سیفیہ: 36 مراقبات</SectionTitle>
        {muraqabatData.map((m, i) => (
          <Accordion key={i} title={m.title}>
            <div className="flex flex-col gap-2">
              <span className="text-gold font-bold">فارسی نیت:</span>
              <p className="text-lg leading-relaxed">{m.text}</p>
            </div>
          </Accordion>
        ))}

        {/* Other Silsilas */}
        <SectionTitle>دیگر سلاسل کے اسباق</SectionTitle>
        <Accordion title="اسباق طریقہ عالیہ چشتیہ">
          <ul className="space-y-4 pr-4 border-r-2 border-gold/30">
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">پہلا سبق (کلمہ ھُو):</span> 
              "ھُو" کو روح سے شروع کر کے قلب، سرّ، اخفیٰ، خفی اور پھر روح تک گول دائرے میں گھمائیں اور ایک تلوار فرض کر کے باطن سے نکالیں۔ اسے ایک مینار کی طرح بلاکیف تصور کریں۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">دوسرا سبق (اللّٰه ھُو):</span> 
              "اللّٰه" کا تصور قلب پر اور "ھُو" کا تصور روح پر۔ مینار کے اندر گول دائرہ کی شکل پر سیڑھیاں عروج کریں۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">تیسرا سبق (ھُو اللّٰه):</span> 
              "ھُو" کا تصور روح پر اور "اللّٰه" کا تصور قلب پر رکھ کر بالکل سیدھا طور پر عروجات کریں۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">چوتھا سبق:</span> 
              <span className="arabic-text text-xl text-gold-light block my-2">اَنْتَ الْهَادِي اَنْتَ الْحَقُّ لَيْسَ الْهَادِي إِلَّا هُوَ</span>
              "انت الھادی انت" قلب پر، "الحق" اخفیٰ پر، "لیس الھادی" اخفیٰ سے واپس، "الا" قلب پر اور "ھو" روح پر رکھ کر پڑھیں۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">مراقبہ چشتیہ:</span> 
              مدینہ منورہ کی طرف منہ کر کے سانس بند کر کے قلب میں "اللّٰہ ھُو" کہیں۔ 5 منٹ یا 4 رکعت نماز کی مقدار۔<br/>
              <span className="text-gold font-bold italic">نیت: "فیض می آید از ذاتِ بے چوں بلطیفہ قلب من، بواسطہ پیرانِ کبار، خصوصاً حضرت خواجہ معین الدین چشتی رحمۃ اللہ علیہ"</span>
            </li>
          </ul>
        </Accordion>

        <Accordion title="اسباق طریقہ عالیہ قادریہ">
          <div className="bg-gold/10 p-4 rounded-xl text-center mb-4 border border-dashed border-gold">
            <span className="text-gold-light font-bold block mb-2">روزانہ صبح طلوعِ آفتاب سے قبل 313 مرتبہ:</span>
            <span className="arabic-text text-2xl text-gold-light block">اَسْتَغْفِرُ اللّٰهَ الَّذِيْ لَا اِلٰهَ اِلَّا هُوَ الْحَيُّ الْقَيُّوْمُ وَاَتُوْبُ اِلَيْهِ</span>
          </div>
          <ul className="space-y-4 pr-4 border-r-2 border-gold/30">
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">پہلا سبق (نفی اثبات):</span> 
              "لا" قلب سے دائیں کندھے، "اِلٰہ" قالبی پر، اور "اِلَّا اللّٰہ" کی ضرب قلب پر۔ 100 دفعہ پڑھنے کے بعد "مُحَمَّدُ رَّسُوْلُ اللّٰہ ﷺ" کہیں۔ تعداد 1000۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">دوسرا سبق (اِلَّا اللّٰہ):</span> 
              ایک بار "لا الہ الا اللہ" کہہ کر شروع کریں، پھر "الا اللہ" کی ضرب قلب پر لگاتے جائیں۔ 100 کے بعد محمد رسول اللہ ﷺ۔ تعداد 1000۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">تیسرا سبق (اسم ذات اللّٰہ):</span> 
              قلب پر، پہلی دفعہ "اللّٰہ جَلَّ جَلَالُہٗ" پھر "اللّٰہ" 100 بار پڑھ کر رکنے کے بعد "جَلَّ جَلَالُہٗ" زبان سے بھی کہیں۔ تعداد 1000۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">چوتھا سبق (ھُو):</span> 
              "ھُو" روح سے، سر، اخفی، خفی سے دوبارہ روح پر لانا ہے۔ تعداد 1000۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">مراقبہ قادریہ:</span> 
              5 منٹ سانس بند کر کے قلب میں اللہ اور روح پر ھُو کہنا ہے۔<br/>
              <span className="text-gold font-bold italic">نیت: "فیض می آید از ذاتِ بے چوں بلطیفہ قلب من، بواسطہ پیرانِ کبار، خصوصاً غوث الاعظم شیخ عبدالقادر جیلانی رحمۃ اللہ علیہ"</span>
            </li>
          </ul>
          <div className="bg-gold/10 p-4 rounded-xl text-center mt-4 border border-dashed border-gold">
            <span className="text-gold-light font-bold block mb-2">ورد کے اختتام پر درود غوثیہ پڑھیں:</span>
            <span className="arabic-text text-2xl text-gold-light block">اَللّٰهُمَّ صَلِّ عَلٰى مُحَمَّدٍ وَّآلِهٖ وَعِتْرَتِهٖ بِعَدَدِ كُلِّ مَعْلُوْمٍ لَّكَ</span>
          </div>
        </Accordion>

        <Accordion title="طریقہ عالیہ سہروردیہ">
          <ul className="space-y-4 pr-4 border-r-2 border-gold/30">
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">طریقہ:</span> 
              اسباق بعینہٖ قادریہ شریف کی طرح اور اسی ترتیب سے ہیں۔
            </li>
            <li className="relative pr-6 before:content-['•'] before:absolute before:right-0 before:text-gold-light before:text-2xl">
              <span className="text-gold-light font-bold text-xl block">مراقبہ سہروردیہ:</span> 
              یہ مراقبہ کم از کم 20 منٹ کا ہے اور اکثر زیادہ کی کوئی حد نہیں۔ اس میں سانس بند کرنا (حبسِ نفس) شرط نہیں ہے۔ آنکھیں بند کر کے لطائف میں ذکر شروع کریں۔<br/>
              <span className="text-gold font-bold italic">نیت: "فیض می آید از ذاتِ بے چوں بلطیفہ قلب من، بواسطہ پیرانِ کبار، خصوصاً حضرت شیخ شہاب الدین سہروردی رحمۃ اللہ علیہ"</span>
            </li>
          </ul>
        </Accordion>

        {/* Shajra Section */}
        <SectionTitle>شجرہ ہائے طریقت (مع تعارف)</SectionTitle>
        <Accordion title="شجرہ نقشبندیہ مجددیہ سیفیہ">
          <ShajraList items={SHAJRA_NAQSHBANDI} />
        </Accordion>
        <Accordion title="شجرہ عالیہ چشتیہ">
          <ShajraList items={SHAJRA_CHISHTIA} />
        </Accordion>
        <Accordion title="شجرہ عالیہ قادریہ">
          <ShajraList items={SHAJRA_QADRIA} />
        </Accordion>
        <Accordion title="شجرہ عالیہ سہروردیہ">
          <ShajraList items={SHAJRA_SUHARWARDIA} />
        </Accordion>

        {/* Introduction */}
        <SectionTitle>تعارف و پیش لفظ</SectionTitle>
        <section className="text-center border-2 border-gold bg-gradient-to-br from-black/80 to-gold/15 p-8 rounded-2xl shadow-2xl mb-8">
          <span className="arabic-text text-3xl block mb-4 drop-shadow-md">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</span>
          <div className="space-y-4 text-lg leading-relaxed text-white">
            <p>
              یہ ڈیجیٹل روحانی خزانہ (ایپ) پیرِ طریقت، رہبرِ شریعت حضرت مولانا <strong className="text-gold-light">محمد الیاس نقشبندی، چشتی، قادری، سہروردی، سیفی</strong> مدظلہ العالی (آستانہ عالیہ نقشبندیہ سیفیہ، گوجرخان) کی سرپرستی اور خصوصی ایماء پر تیار کی گئی ہے۔
            </p>
            <p>
              اس ایپ کو تمام سالکینِ طریقت کے لیے جدید تقاضوں کے مطابق مرتب کرنے کی سعادت <strong className="text-gold-light">خادم محمد حفیظ سیفی اور محمد وقار علی سیفی</strong> نے حاصل کی۔
            </p>
            <p className="text-green-300 italic text-base mt-4">
              دعا ہے کہ اللہ رب العزت اپنے پیارے حبیب ﷺ اور مشائخ عظام کے صدقے اس ادنیٰ سی کاوش کو شرفِ قبولیت بخشے اور تمام سالکین کے لیے نفع بخش بنائے۔ آمین۔
            </p>
          </div>
        </section>

      </main>

      {/* Footer / Floating Info */}
      <footer className="mt-8 text-gray-400 text-sm text-center">
        &copy; {new Date().getFullYear()} معمولاتِ سیفیہ - تمام حقوق محفوظ ہیں۔
      </footer>
      <audio 
        ref={azanAudioRef} 
        preload="auto" 
        onError={(e) => console.error("Azan audio load error", e.currentTarget.error?.message)}
      >
        <source src="https://www.islamcan.com/audio/adhan/azan1.mp3" type="audio/mpeg" />
      </audio>
      <audio 
        ref={tahajjudAudioRef} 
        preload="auto" 
        loop
        onError={(e) => console.error("Tahajjud audio load error", e.currentTarget.error?.message)}
      >
        <source src="https://www.islamcan.com/audio/adhan/azan2.mp3" type="audio/mpeg" />
      </audio>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}